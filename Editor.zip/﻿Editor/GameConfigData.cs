﻿using System;
using System.Collections.Generic;
using UnityEditor;
using LitJson;
using UnityEngine;
using System.IO;
using System.Text;

public class GameConfigData : Editor
{
    [MenuItem("Game/清理数据")]
    static void ClearAllPlayerPrefs()
    {
        PlayerPrefs.DeleteAll();
    }


    static string GoogleDocUrl =
        "https://docs.google.com/spreadsheets/d/e/2PACX-1vSPEry6_h5O0ZWEhIdrRnNseQ7KFRPXRUEz1jOlAbKbCc8zKgT4COc0etem1Qt0ebENJ0z5unGuiFwr/pub?gid={0}&single=true&output=csv";

    [MenuItem("Game/更新数据/所有数据")]
    static void UpgradeAllRoleDB()
    {
        UpgradeRolePropertyDB();
        UpgradeRoleBaseDB();
    }

    [MenuItem("Game/更新数据/角色属性")]
    static void UpgradeRolePropertyDB()
    {
        string id = "1866782997";
        string tUrl = string.Format(GoogleDocUrl, id);
        Debug.LogError("开始更新角色属性数据");
        string[][] tStringArr = LoadFromWeb(tUrl);
        Log(tStringArr);
        Dictionary<string, RoleProperty> RoleBasedAttributesDic = new Dictionary<string, RoleProperty>();
        RoleProperty tRoleProperty;
        try
        {
            for (int i = 1; i < tStringArr.Length; i++)
            {
                tRoleProperty = new RoleProperty();

                tRoleProperty.describe = tStringArr[i][0];
                tRoleProperty.id = int.Parse(tStringArr[i][1]);
                tRoleProperty.skillMaxLevel = int.Parse(tStringArr[i][2]);
                tRoleProperty.property = float.Parse(tStringArr[i][3]);
                tRoleProperty.propertyGrowth = float.Parse(tStringArr[i][4]);
                tRoleProperty.price = float.Parse(tStringArr[i][5]);
                tRoleProperty.priceGrowth = float.Parse(tStringArr[i][6]);
                tRoleProperty.Type =
                    (PropertyType) Enum.Parse(typeof(PropertyType), tStringArr[i][7]);
                RoleBasedAttributesDic.Add(tStringArr[i][1], tRoleProperty);
            }

            string tJson = JsonMapper.ToJson(RoleBasedAttributesDic);
            File.WriteAllText(RolePropertyDB.Path, tJson);
        }
        catch (Exception e)
        {
            Debug.LogError("解析出错了");
            Debug.LogError(e);
        }

        AssetDatabase.Refresh();
        AssetDatabase.SaveAssets();
        Debug.LogError("角色属性数据更新完成");
    }

    [MenuItem("Game/更新数据/角色")]
    static void UpgradeRoleBaseDB()
    {
        string id = "2024982639";
        string tUrl = string.Format(GoogleDocUrl, id);
        Debug.LogError("开始更新角色基本数据");
        string[][] tStringArr = LoadFromWeb(tUrl);
        Log(tStringArr);
        List<RoleBaseData> RoleBasedDB = new List<RoleBaseData>();
        RoleBaseData tData;
        for (int i = 1; i < tStringArr.Length; i++)
        {
            tData = new RoleBaseData();
            tData.name = (RoleName) Enum.Parse(typeof(RoleName), tStringArr[i][1]);
            tData.property = new List<string>(tStringArr[i][2].Split('|'));
            tData.skills = new List<string>(tStringArr[i][3].Split('|'));
            tData.maxLevel = int.Parse(tStringArr[i][4]);
            tData.camp = (RoleCamp) int.Parse(tStringArr[i][5]);
            tData.attackMode = int.Parse(tStringArr[i][6]);
            tData.occupation = (RoleOccupation) int.Parse(tStringArr[i][7]);

            RoleBasedDB.Add(tData);
        }

        string tJson = JsonMapper.ToJson(RoleBasedDB);
        File.WriteAllText(RoleBaseDB.Path, tJson);

        AssetDatabase.Refresh();
        AssetDatabase.SaveAssets();
        Debug.LogError("角色基本数据更新完成");
    }


    static string[][] LoadFromWeb(string url)
    {
        Debug.LogError(url);
        WWW www = new WWW(url);
        string[][] tCsv = null;
        Debug.LogError("正在下载资源");
        while (!www.isDone)
        {
        }

        if (www.error == null)
        {
            Debug.LogError("资源下载成功");
            tCsv = CsvParser2.Parse(www.text);
        }
        else
        {
            Debug.LogError("资源下载失败 需要小飞机全局翻墙");
        }

        return tCsv;
    }

    static void Log(string[][] tArr)
    {
        StringBuilder tSb = new StringBuilder();
        foreach (var item1 in tArr)
        {
            foreach (var item2 in item1)
            {
                tSb.AppendFormat("{0,20}", item2);
            }

            tSb.AppendFormat("\n");
        }

        Debug.LogError(tSb.ToString());
    }
}